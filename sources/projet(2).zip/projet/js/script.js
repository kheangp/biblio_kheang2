 $(document).ready(function()
		{
			
			menu=$('.menu'),
			zone=$('.zone'),
			mborder=$('.mborder');
			fixe=$('.fixe'),
			bar=$('.bar');
			vert=$('#vert');
			bleu=$('#bleu');
			container2=('.container2');
			dev=$('#dev');
			contenu=$('.contenu');
			layout1=$('.layout1');
			layout1img=$('#layout1img');
			
			chargement=$('.chargement');
			papillon=$('#papillon');
			papimg=$('#papimg');
			yutube=$('#yutube');
			ytimg=$('#ytimg');
			
			chargement2=$('.chargement2');
			papillon2=$('#papillon2');
			chargement3=$('.chargement3');
			yutube2=$('#yutube2');
			
			// <!-- container2.scroll(function() { -->
			// <!-- alert('scroll'); -->
			// <!-- }); -->
			
			papillon.click(function()  //Méthode avec la fonction mouseover() quand souris sur le menu -->
			 {      
			 
			 // chargement.html("<img id=\"papimg\"src=\"images/amiral.png\"/>");
			 //chargement.load("page1.php");
			 
			   (chargement.load("page1.php")).show('slow');
    
	
	
	
	
	/*
    $('button:eq(1)').click(function() {
      $('tr:odd').hide(1000);
    });*/
			 
				
			});
			
			yutube.click(function()  //Méthode avec la fonction mouseover() quand souris sur le menu -->
			 {      
			 
			 
			 
			   // chargement.html("<img id= \"ytimg\" src=\"images/youtube.png\"/>");
			   chargement.load("page2.php");
			 
				
			});
				
			
    papillon2.click(function() {
		chargement3.hide('fast');
      chargement2.show('slow');
	  
    } ); 
	
    yutube2.click(function() 
	{
		alert('dedans');
	chargement2.hide('fast');
	  chargement3.show('slow');
      
    });
	
	
				
				
				
				
				
				
				
				
				vert.click(function()   //2eme methode
									{	
									dev.css('display','block');
									});
									
			
			layout1img.mouseover(function()  //Méthode avec la fonction mouseover() quand souris sur le menu -->
			 {      
			 
			   layout1img.css('padding-top','10px');
			 
				layout1img.css("filter","drop-shadow(5px 5px 5px white)");
				layout1img.animate();
			});
			
			layout1.mouseout(function()  //Méthode avec la fonction mouseover() quand souris sur le menu -->
			 {      
			  layout1img.css('padding-top','5px');
			 
				layout1img.css("filter","none");
			});
			
			
			layout1img.animate({ 								
								paddingRight : '0'
								
						
							}, 'swing'); 
			/*menu.mouseout(function()  //Méthode avec la fonction mouseover() quand souris part en vacances
			{
		
				zone.css('display','none');
				
			});*/
				
			
			// <!-- dev.on('click', function() -->
			// <!-- { -->
			// <!-- bar.css('display', 'block'); -->
			// <!-- }); -->
			
nbobs = 3568;

function compteur_anim() 
{
    $('.compteur b').animate(
	{
        
        nbobs: nbobs
    }, {
        duration: 1000,
        easing: 'swing',
        step: function(now) 
		{
            $(this).text(Math.ceil(now));
        },
        complete: compteur_anim
    });
};




compteur_anim();


			
		});	