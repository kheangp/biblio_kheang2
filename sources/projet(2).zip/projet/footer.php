<footer class="pied">
		<div class="container-fluid containerp">
			<div class="row">
				<div class="col-5">
				<img src="images/logop.svg"/></br></br>
				<p> Get the most for your website with Intense Multipurpose Website Template, valued by over 3,000 customers worldwide. With a great number of pages, components, elements, and blocks, this responsive Bootstrap 4 template is definitely worth your attention.</p></div>
				<div class="col-7">178 West 27th Street, Suite 527, New York NY 10012, United States
					<div class="container containerp">
						<div class="row ">
							<div class="col-4 tel"><svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-telephone" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M3.654 1.328a.678.678 0 0 0-1.015-.063L1.605 2.3c-.483.484-.661 1.169-.45 1.77a17.568 17.568 0 0 0 4.168 6.608 17.569 17.569 0 0 0 6.608 4.168c.601.211 1.286.033 1.77-.45l1.034-1.034a.678.678 0 0 0-.063-1.015l-2.307-1.794a.678.678 0 0 0-.58-.122l-2.19.547a1.745 1.745 0 0 1-1.657-.459L5.482 8.062a1.745 1.745 0 0 1-.46-1.657l.548-2.19a.678.678 0 0 0-.122-.58L3.654 1.328zM1.884.511a1.745 1.745 0 0 1 2.612.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.678.678 0 0 0 .178.643l2.457 2.457a.678.678 0 0 0 .644.178l2.189-.547a1.745 1.745 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.634 18.634 0 0 1-7.01-4.42 18.634 18.634 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877L1.885.511z"/>
</svg><span> +1 234 567 8901</span> <br>
												<span>+1 234 567 8902</span>

							</div>
							<div class="col-4 horaire"><span>Mon-Fri: 8am - 6pm</span><br>
												<span>Sat-Sun: 8am - 4pm</span><br>
											   <span> Holidays: closed</span>

							</div>
							<div class="col-4 contact"><a href="mailto:mail@example.com">mail@example.com</a><br>
												<a href="mailto:mail@example.com">info@example.com</a>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-4 policy">© 2019 Intense. All rights reserved.<a href="#">Privacy Policy</a></div>
				<div class="col-5"></div>
				<div class="col-3 icones">
                            <i class="fab fa-youtube"></i>
                            <i class="fab fa-facebook-f"></i>
                            <i class="fab fa-instagram"></i>
                            <i class="fab fa-twitter"></i>
                            <i class="fab fa-linkedin"></i>
                            </div>
			</div>
		</div>
	</footer>
	  