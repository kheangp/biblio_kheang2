<DOCTYPE! html>
<html>
	<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/style.css" rel="stylesheet" >
	<link href="http://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	</head>

	<body>
		
	


        <?php
            
            require_once 'navbar.php';
			include 'zone1.php';
            
			include 'main.php';
           
		   
		   
		    require_once 'footer.php';
           
		   
            
        ?>
        
	</body>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
	 <script src="js/icons.js"></script>
	 <script src="js/script.js"> </script>
	 
</html>	