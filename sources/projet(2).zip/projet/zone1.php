<div>
	<div class="slideshow">
	<img src="images/automne.jpg" />
	
	</div>
	
	<div class="slideshow">
	<img src="images/noir.jpg" />
	</div>
	
	
	<div class="slideshow">
	<img src="images/or.jpg" />
	</div>
	
</div>	