<table>
  <tbody>
    <tr>
      <td>Trusted by</td>
	  <td class="compteur" id="obs"><b nbobs="0">0</b></td>
	  <td>users</td>
      <!-- <td class="compteur" id="sps"><b nbsps="0">0</b></td> -->
    </tr>
  </tbody>
</table>



	
	
	<div class="zone3">
	<div class="container">
		<div class="row">
			<div class="col-3">
			</div>
			<div class="col-6">
			<div class="row z3titl">
				<h2 class="">Discover the latest trends in
web design and development</h2>
				<p>Trying to stay on top of it all? Get the best tools, resources and inspiration sent to your inbox weekly.</p>
				 <input type="text" value="Enter your email adress"/><input type="button" class="btn btn-success" value="subscribe"/>
				</p>
			</div>
			</div>
			<div class="col-3">
			</div>
		</div>
	</div>
	<!--
	<div class="col-6">
	<div class="row">
		<a href="#" class="col" id="papillon2" >Design2</a>
		<a href="#" class="col" id="yutube2" >Developpement2</a>
	
	</div>
	
	<div class="row chargement2"><img src="images/amiral.png"/></div>
	<div class="row chargement3"><img src="images/youtube.png"/></div>
	</div>
	
	-->
	
</div>
<div class="row">
<div class="col-6"><h4>
Even more
features available

Take a look at an extensive list of features
that our template has to offer.</h4>
</div>

	<div class="col-6">
	<div class="navbar zonez">
		<a href="#zonez" class="col" id="papillon" >Design
		<div class="mborberz"></div></a>
		
		<a href="#zonez" class="col" id="yutube" >Developpement
		<div class="mborderz"></div></a>
	
	</div>
	<div class=" chargement">
	<img id="papimg"src="images/amiral.png"/>
	
	</div>
	
</div>


	
	
	<div class="row ">
	<div class="col-10 layout1  pt-5">
	<a href="#" ><img id="layout1img" src="images/layout1.jpg"/></a>
	</div>
	</div>
	
	<div class="zone2">
	<div class="container container2">
	<div class="row">
		<div class="col-6 fixe">
			Even more
			features available
			Take a look at an extensive list of features
			that our template has to offer.

		
		</div>
		
		
		
		<div class="contenu">
		</div>
			<div id="dev">
			
	
					Based on Bootstrap 4
				Sliders and carousels
				Parallax
				Lots of header layouts
				A variety of footer layouts
				Icon fonts
				Video background

				Based on Bootstrap 4
				Sliders and carousels
				Parallax
				Lots of header layouts
				A variety of footer layouts
				Icon fonts
				Video background
				26 child themes
				Based on Bootstrap 4
				Sliders and carousels
				Parallax
				Lots of header layouts
				A variety of footer layouts
				Icon fonts
				Video background
				26 child themes
				Based on Bootstrap 4
				Sliders and carousels
				Parallax
				Lots of header layouts
				A variety of footer layouts
				Icon fonts
				Video background
				26 child themes
				Based on Bootstrap 4
				Sliders and carousels
				Parallax
				Lots of header layouts
				A variety of footer layouts
				Icon fonts
				Video background
				26 child themes
				Based on Bootstrap 4
				Sliders and carousels
				Parallax
				Lots of header layouts
				A variety of footer layouts
				Icon fonts
				Video background
				26 child themes
				Based on Bootstrap 4
				Sliders and carousels
				Parallax
				Lots of header layouts
				A variety of footer layouts
				Icon fonts
				Video background
				26 child themes
				Based on Bootstrap 4
				Sliders and carousels
				Parallax
				Lots of header layouts
				A variety of footer layouts
				Icon fonts
				Video background
				26 child themes
				Based on Bootstrap 4
				Sliders and carousels
				Parallax
				Lots of header layouts
				A variety of footer layouts
				Icon fonts
				Video background
				26 child themes
				26 child themes
			</div>
			</div>
	</div>
	</div>
	</div>
	

	
	<div class="container">
		<div class="row">
			<div class="col-6">
				<ul class="listepage">Pages			
				 <li>404.page</li>
				 <li>503.page</li>
				 <li>Schaefer</li>
				 </ul>
			</div>
			<div class="col-6">
			<ul>	Components				
				 <li>Accordeins</li>
				 <li>Alerts</li>
				 <li>Animations</li>
				</ul>
			</div>
		</div>
		
	</div>
	</div>
