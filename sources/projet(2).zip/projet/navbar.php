<header>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
	<div class="container-fluid">
		<div class="row border border-primary">
				<div class="col-3 menu border border-primary"><img src="images/logo.svg"/></div>
				<div class="col-7 menu border border-primary">
					<!-- <div class="container" id="nav"> -->
					<div class="collapse navbar-collapse" id="navbarSupportedContent">
						<ul class="navbar-nav mr-auto">
					  <li class="nav-item active">
						<a class="nav-link" href="#">Home <div class="mborder"></div><span class="sr-only">(current)</span></a>
					  </li>
					  <li class="nav-item">
						<a class="nav-link" href="#">Features<div class="mborder"></div></a>
					  </li>
					   <li class="nav-item">
						<a class="nav-link" href="#">Pages<div class="mborder"></div></a>
					  </li>
					  <li class="nav-item">
						<a class="nav-link" href="#">Portfolio<div class="mborder"></div></a>
					  </li>
					  <li class="nav-item">
						<a class="nav-link" href="#">Blog<div class="mborder"></div></a>
					  </li>
					  <li class="nav-item">
						<a class="nav-link" href="#">Shop<div class="mborder"></div></a>
					  </li>
						<li class="nav-item">
						<a class="nav-link" href="#">Components<div class="mborder"></div></a>
					  </li>
					  <li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						  Dropdown
						</a>
						<div class="dropdown-menu" aria-labelledby="navbarDropdown">
						  <a class="dropdown-item" href="#">Action</a>
						  <a class="dropdown-item" href="#">Another action</a>
						  <div class="dropdown-divider"></div>
						  <a class="dropdown-item" href="#">Something else here</a>
						</div>
					  </li>
					</div>
				</div>
				<div class="col-2">
				<!-- <div class="container" id="shop"> -->
					  <form class="form-inline my-2 my-lg-0">
					  <a href="#" src="images/logosearch.png"></a>
					  <button class="btn btn-outline-success my-2 my-sm-0" type="submit"></button>
					  <button class="recherche"><img src="images/logosearch.png"/><img src="images/logocaddie.png"/></button>
					</form>
				</div>
		</div>
	</div>
			
	</nav>
	</header>